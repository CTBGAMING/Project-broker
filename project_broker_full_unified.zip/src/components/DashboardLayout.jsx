
import React from 'react';
import Sidebar from './Sidebar.jsx';
export default function DashboardLayout({ children, role }) {
  return (<div className="flex min-h-screen bg-[#0b0b0b] text-white"><Sidebar role={role}/><div className="flex-1 p-8 overflow-auto">{children}</div></div>);
}
