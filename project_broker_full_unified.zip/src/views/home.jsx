
import React from 'react';
import { Link } from 'react-router-dom';

export default function Home(){
  return (
    <div className="min-h-screen">
      <header className="w-full p-6 bg-white/90 shadow sticky top-0 z-40">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-extrabold">Project <span className="text-yellow-400">Broker</span></h1>
          <nav className="flex gap-4">
            <Link to="/auth" className="hover:underline">Login</Link>
            <Link to="/auth" className="btn-primary px-4 py-2 rounded">Get Started</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-8">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl font-extrabold mb-4">Find trusted contractors & event vendors — fast.</h2>
            <p className="text-gray-700 mb-6">Project Broker connects customers to local contractors and event professionals using a secure bidding & escrow system. Create a project, choose services, receive competitive bids and hire with confidence.</p>
            <div className="flex gap-4">
              <Link to="/auth" className="btn-primary px-6 py-3 rounded">Start a Project</Link>
              <Link to="/auth" className="px-6 py-3 rounded border">Learn More</Link>
            </div>
            <ul className="mt-6 grid grid-cols-2 gap-2 text-sm text-gray-600">
              <li>Free to place a job</li>
              <li>Scoper visits: R400</li>
              <li>Emergency callout: R850</li>
              <li>Secure escrow payments</li>
            </ul>
          </div>
          <div>
            <img src="/src/assets/hero_builders.jpg" alt="construction hero" className="hero-img shadow-lg"/>
          </div>
        </section>

        <section className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="card">
            <h3 className="font-bold mb-2">How it works</h3>
            <ol className="text-sm text-gray-300">
              <li>1. Create a project and pick services</li>
              <li>2. Vendors place bids & BOQs</li>
              <li>3. Inspectors verify work & release escrow</li>
            </ol>
          </div>
          <div className="card">
            <h3 className="font-bold mb-2">For Contractors</h3>
            <p className="text-sm text-gray-300">Get verified leads, submit BOQs and grow your business.</p>
          </div>
          <div className="card">
            <h3 className="font-bold mb-2">For Event Planners</h3>
            <p className="text-sm text-gray-300">Manage multiple vendors, upload inspiration and secure bookings.</p>
          </div>
        </section>

        <section className="mt-12">
          <h3 className="text-2xl font-bold mb-4">Trusted by customers & businesses</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="card">“Found a plumber in hours.” — A. M.</div>
            <div className="card">“Great platform for event vendors.” — S. K.</div>
            <div className="card">“Corporate job import saved us time.” — P. R.</div>
          </div>
        </section>

      </main>
    </div>
  )
}
