
import React from 'react';
import DashboardLayout from '../../components/DashboardLayout.jsx';

export default function InspectorDashboard() {
  return (
    <DashboardLayout role="inspector">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">Inspector Panel</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card">Quick actions & stats</div>
          <div className="card">Recent items</div>
          <div className="card">Shortcuts</div>
        </div>
      </div>
    </DashboardLayout>
  );
}
