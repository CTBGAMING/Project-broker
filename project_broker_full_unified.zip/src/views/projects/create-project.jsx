
import React, { useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { supabase } from '../../lib/supabase.js';
import UploadButton from '../../components/UploadButton.jsx';

const CONSTRUCTION = ['Plumbing','Electrical','Roofing','Carpentry','Built-In Cabinets','Tiling','Painting','Waterproofing','General Repairs','Concrete / Masonry','Paving','Glazing / Windows','Ceilings / Drywall'];
const EVENTS = ['Catering','Decor','Flowers','DJ','Transport','Photography','Videography','Entertainment','Lighting / AV','Venue Logistics'];

function YesNoDont(){ return (<select className="p-2 rounded w-full"><option>Yes</option><option>No</option><option>I don't know</option></select>); }

export default function CreateProject(){
  const [title,setTitle]=useState(''); const [desc,setDesc]='';
  const [type,setType]=useState('Construction');
  const [selected,setSelected]=useState([]);
  const [details,setDetails]=useState({}); const [inspiration,setInspiration]=useState({});
  function toggle(cat){ setSelected(prev=> prev.includes(cat) ? prev.filter(x=>x!==cat) : [...prev,cat]); }
  function update(cat,key,val){ setDetails(prev=> ({...prev, [cat]: {...(prev[cat]||{}), [key]: val }})); }
  function addInspiration(cat,url){ setInspiration(prev=> ({...prev, [cat]: [...(prev[cat]||[]), url]})); }
  async function handleSubmit(e){
    e.preventDefault();
    const { data:{ user } } = await supabase.auth.getUser();
    if(!user) return alert('Login required');
    const { data: project, error } = await supabase.from('projects').insert([{ owner_id: user.id, project_name: title, description: desc, project_type: type, categories: selected }]).select().single();
    if(error) return alert(error.message);
    // create an ad per selected category and store details + inspiration
    const ads = selected.map(cat=> ({ project_id: project.id, category: cat, description: JSON.stringify({ details: details[cat]||{}, inspiration: inspiration[cat]||[] }), is_emergency:false, bid_closes_at: new Date(Date.now()+1000*60*60*24*3).toISOString() }));
    const { error: aerr } = await supabase.from('ads').insert(ads);
    if(aerr) return alert(aerr.message);
    alert('Project created and ads posted');
  }

  const panelFor = (cat) => {
    if(CONSTRUCTION.includes(cat)){
      return (<div className="card mb-3"><h4 className="font-semibold mb-2">{cat} Details</h4>
        <label className="block mb-2">Describe the issue or requirement (or select "I don't know")<textarea className="w-full p-2" onChange={e=>update(cat,'description',e.target.value)} /></label>
        <label className="block mb-2">Is access to stopcock/shutoff available?{YesNoDont()}</label>
        <label className="block mb-2">Preferred material (or I don't know)</label>
        <select className="p-2 rounded w-full" onChange={e=>update(cat,'material',e.target.value)}><option>I don't know</option><option>PVC</option><option>Copper</option><option>Wood</option><option>Other</option></select>
        <div className="mt-2"><UploadButton folder={`inspiration/${cat}`} onUpload={(url)=>addInspiration(cat,url)} label="Upload Inspiration / Photos" /></div>
        <div className="flex gap-2 mt-2">{(inspiration[cat]||[]).map((p,i)=>(<img key={i} src={p} className="w-20 h-20 object-cover rounded"/>) )}</div>
      </div>)
    } else {
      // Events panel
      return (<div className="card mb-3"><h4 className="font-semibold mb-2">{cat} Details</h4>
        <label className="block mb-2">Provide details (or "I don't know")<textarea className="w-full p-2" onChange={e=>update(cat,'description',e.target.value)} /></label>
        {['Decor','Flowers','Transport','Lighting / AV'].includes(cat) && (<div className="mt-2"><UploadButton folder={`inspiration/${cat}`} onUpload={(url)=>addInspiration(cat,url)} label="Upload Inspiration Image" /><div className="flex gap-2 mt-2">{(inspiration[cat]||[]).map((p,i)=>(<img key={i} src={p} className="w-20 h-20 object-cover rounded"/>) )}</div></div>)}
      </div>)
    }
  }

  return (<DashboardLayout role="customer"><h1 className="text-2xl font-bold mb-4">Create Project</h1><form onSubmit={handleSubmit}><div className="grid md:grid-cols-2 gap-4"><input className="w-full p-3 mb-3" placeholder="Project title" value={title} onChange={e=>setTitle(e.target.value)}/><select className="w-full p-3 mb-3" value={type} onChange={e=>setType(e.target.value)}><option>Construction</option><option>Events</option></select></div><textarea className="w-full p-3 mb-3" placeholder="Short description" value={desc} onChange={e=>setDesc(e.target.value)}/><div className="card p-4 mb-3"><h4 className="font-semibold mb-2">Select categories</h4><div className="grid md:grid-cols-3 gap-2">{(type==='Construction' ? CONSTRUCTION : EVENTS).map(cat=>(<label key={cat} className='inline-flex items-center gap-2 border p-2 rounded'><input type="checkbox" checked={selected.includes(cat)} onChange={()=>toggle(cat)}/> <span>{cat}</span></label>))}</div></div><div className="mt-4">{selected.map(cat=> panelFor(cat))}</div><div className="flex justify-end mt-4"><button className="btn-primary">Create Project</button></div></form></DashboardLayout>);
}
