
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './views/home.jsx';
import AuthPage from './views/auth/auth.jsx';
import CustomerDashboard from './views/dashboards/customer.jsx';
import ContractorDashboard from './views/dashboards/contractor.jsx';
import AdminDashboard from './views/dashboards/admin.jsx';
import ScoperDashboard from './views/dashboards/scoper.jsx';
import InspectorDashboard from './views/dashboards/inspector.jsx';
import CorporateDashboard from './views/dashboards/corporate.jsx';
import CreateProject from './views/projects/create-project.jsx';
import PlaceBid from './views/bidding/place-bid.jsx';
import ContractPage from './views/contracts/contract.jsx';
import NotFound from './views/not-found.jsx';

export default function App(){ return (<Routes>
  <Route path='/' element={<Home/>} />
  <Route path='/auth' element={<AuthPage/>} />
  <Route path='/dashboard/customer' element={<CustomerDashboard/>} />
  <Route path='/dashboard/customer/create' element={<CreateProject/>} />
  <Route path='/dashboard/contractor' element={<ContractorDashboard/>} />
  <Route path='/dashboard/admin' element={<AdminDashboard/>} />
  <Route path='/dashboard/scoper' element={<ScoperDashboard/>} />
  <Route path='/dashboard/inspector' element={<InspectorDashboard/>} />
  <Route path='/dashboard/corporate' element={<CorporateDashboard/>} />
  <Route path='/bidding/place/:adId' element={<PlaceBid/>} />
  <Route path='/contract/:jobId' element={<ContractPage/>} />
  <Route path='*' element={<NotFound/>} />
</Routes>); }
